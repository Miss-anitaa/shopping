$(document).ready(function() {
    $("#nav-menu-btn").click(function() {
        $("#nav-menu").fadeToggle()
    })
});